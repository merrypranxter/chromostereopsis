# chromostereopsis

> red floats. blue sinks. your own eyeball does the 3D. no glasses.

## what it does

Pure saturated red and pure blue at the same depth appear at **different** depths — red advances, blue recedes — because of longitudinal chromatic aberration in your own eye. Flat art that pops into layers with zero stereo trick.

**Sibling of `chromadepth`** — cross-link hard:
- `chromadepth` = engineered depth via **ChromaDepth GLASSES** (red→near, blue→far).
- `chromostereopsis` = **naked-eye**, no glasses, exploits your eye's own chromatic aberration; effect can even **reverse** per viewer.

## engines

- `redblue_field.glsl` — max-separation pure-primary field.
- `depth_from_hue.glsl` — map scene depth → red↔blue axis.
- `polarity_flip.glsl` — black vs white background (effect inverts).
- `edge_tuning.glsl` — thin red figures on blue ground.
- `breathing.glsl` — animate red→blue so layers pulse.
- `ca_enhance.glsl` — subtle chromatic aberration boost (`chromatic_aberration`).

## pipeline

1. scene/pattern → assign layer/depth → map to red→blue axis.
2. render **maximum-saturation** pure-channel colors on controlled background.
3. optional CA enhancement pass.
4. minimal post (heavy finishers kill the effect).

## aesthetic regimes

- `deep_field` — starfield, red near / blue far, black ground.
- `floating_glyphs` — red sigils hovering off blue plane.
- `polarity_demo` — same art on black vs white, side by side (watch invert).
- `breathing_layers` — slow red↔blue cycle, depth pulses.
- `type_pops` — red text floating off blue.

## parameters

```
mode: deep_field | floating_glyphs | polarity_demo | breathing | type_pops
background: black | white
saturation: 1.0 (must be max)
ca_enhance: 0.0–1.0
```

## gotchas

- **effect strength + direction vary per person** — some see it reversed. Say so.
- needs MAX saturation + pure R/B. Orange/cyan are weak.
- background polarity flips it.
- best at certain viewing distances.
- don't over-design — heavy finishers destroy it.

## ecosystem

**Consumes:** `chromatic_aberration`, `color_systems`  
**Consumed by:** none  
**Adjacent:** `anaglyph_stereo`, `parallax_depth_fields`, `pulfrich_effect`, `wiggle_stereoscopy`  
**Sibling:** `chromadepth` (hard cross-link)  
**Lane:** 3 (perceptual)
